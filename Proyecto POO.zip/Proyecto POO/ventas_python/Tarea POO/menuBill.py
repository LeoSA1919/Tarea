from components import Menu,Valida
from utilities import colorNegro1,colorNegro2,colorAzul1,colorAzul2,colorVerde1,colorVerde2,colorAmarillo1,colorAmarillo2,colorRojo1 ,colorRojo2,colorMagenta1,colorMagenta2 ,colorCyan1,colorCyan2, colorReset, borrarPantalla
from clsJson import JsonFile
from crudClients import CrudClients
from crudSales import CrudSales
from crudProducts import CrudProducts
from customer import RegularClient
from sales import Sale
from product  import Product
from iCrud import ICrud
import datetime, time
import json
import os
from functools import reduce

path, _ = os.path.split(os.path.abspath(__file__))

opc=''
while opc != '4':  
    borrarPantalla()   
    menu_main = Menu("Menu Facturacion",["Clientes","Productos","Ventas","Salir"],50,2)
    opc = menu_main.menu()
    if opc == "1":
        opc1 = ''
        while True:
            borrarPantalla()    
            clients = CrudClients()
            menu_clients = Menu("Menu Cientes",["Ingresar","Actualizar","Eliminar","Consultar","Salir"],50,2)
            opc1 = menu_clients.menu()
            if opc1 == "1":
                clients.create()
            elif opc1 == "2":
                clients.update()
            elif opc1 == "3":
                clients.delete()
            elif opc1 == "4":
                clients.consult()
            
            elif opc1 == "5":
                print("Regresando al menú principal...")
                time.sleep(2) 
                break

            else: 
                print()
                print(colorRojo2+"☠️ ⚠️  Error! dato incorrecto"+colorReset)
                time.sleep(1)   
                print("Regresando al inicio...")
                time.sleep(3)    
                       
    elif opc == "2":
        opc2 = ''
        while True:
            borrarPantalla()   
            products = CrudProducts() 
            menu_products = Menu("Menu Productos",["Ingresar","Actualizar","Eliminar","Consultar","Salir"],50,2)
            opc2 = menu_products.menu()
            if opc2 == "1":
                products.create()
            elif opc2 == "2":
                products.update()
            elif opc2 == "3":
                products.delete()
            elif opc2 == "4":
                products.consult()

            elif opc2 == "5":
                print("Regresando al menú principal...")
                time.sleep(2) 
                break

            else: 
                print()
                print(colorRojo2+"☠️ ⚠️  Error! dato incorrecto"+colorReset)
                time.sleep(1)   
                print("Regresando al inicio...")
                time.sleep(3)   

    elif opc == "3":
        opc3 =''
        while True:
            borrarPantalla()
            sales = CrudSales()
            menu_sales = Menu("Menu Ventas",["Registro Venta","Consultar","Modificar","Eliminar","Salir"],50,2)
            opc3 = menu_sales.menu()
            if opc3 == "1":
                sales.create()
                
            elif opc3 == "2":
                sales.consult()

            elif opc3 == "3":
                sales.update()

            elif opc3 == "4": 
                sales.delete()

            elif opc3 == "5":
                print("Regresando al menú principal...")
                time.sleep(2) 
                break

            else: 
                print()
                print(colorRojo2+"☠️ ⚠️  Error! Dato incorrecto"+colorReset)
                time.sleep(1)   
                print("Regresando al inicio...")
                time.sleep(3)   

     
    elif opc == "4": 
        print(colorAmarillo1+"⚠️  Saliendo del programa..."+colorReset)
        time.sleep(2)
        break

    else: 
        print()
        print(colorRojo2+"☠️ ⚠️  Error! Dato incorrecto"+colorReset)
        time.sleep(1)   
        print("Regresando al inicio...")
        time.sleep(3)            

borrarPantalla()
input(colorAzul1+" Presione una tecla para salir..."+colorReset)
borrarPantalla()

