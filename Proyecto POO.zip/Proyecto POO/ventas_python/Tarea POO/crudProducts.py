from iCrud import ICrud
from iCrud import ICrud
from utilities import borrarPantalla,gotoxy
from utilities import colorNegro1,colorNegro2,colorAzul1,colorAzul2,colorVerde1,colorVerde2,colorAmarillo1,colorAmarillo2,colorRojo1 ,colorRojo2,colorMagenta1,colorMagenta2 ,colorCyan1,colorCyan2, colorReset
from rich.table import Table 
from rich.console import Console
import datetime
import time,os
from components import Valida
import json
from clsJson import JsonFile

path, _ = os.path.split(os.path.abspath(__file__))

from iCrud import ICrud
from iCrud import ICrud
from utilities import borrarPantalla,gotoxy
from utilities import colorNegro1,colorNegro2,colorAzul1,colorAzul2,colorVerde1,colorVerde2,colorAmarillo1,colorAmarillo2,colorRojo1 ,colorRojo2,colorMagenta1,colorMagenta2 ,colorCyan1,colorCyan2, colorReset
from rich.table import Table 
from rich.console import Console
import datetime
import time,os
from components import Valida
import json
from clsJson import JsonFile

path, _ = os.path.split(os.path.abspath(__file__))

class CrudProducts(ICrud):
    def create(self):
        validar = Valida()
        borrarPantalla()
        print('\033c', end='')
        gotoxy(2,2);print(colorVerde1+"*"*90+colorReset) 
        gotoxy(7,3);print(colorMagenta1+"ID"+colorReset) 
        gotoxy(15,3);print(colorMagenta1+"Descripcion"+colorReset) 
        gotoxy(30,3);print(colorMagenta1+"precio"+colorReset) 
        gotoxy(45,3);print(colorMagenta1+"stock"+colorReset) 
        gotoxy(60,3);print(colorAzul2+"n-> finalizar agregacion)"+colorReset)

        follow = "s"
        line = 1
        json_file = JsonFile(path+'/archivos/products.json')
        lectura = json_file.read()

        while follow.lower() == "s":
            while True: 
                id = validar.numeros_(colorRojo2+"valor invalido"+colorReset, 7, 3+line)
                descripcion = validar.letras_(colorRojo1+"Error"+colorReset, 15,3+line)
                precio = validar.precio(colorRojo1+"out of range"+colorReset,colorRojo1+"valor invalido"+colorReset,30,3+line)
                stock = validar.stock(colorRojo2+"out of range"+colorReset,colorRojo1+"valor invalido"+colorReset,45,3+line)
                gotoxy(60,3+line);follow = input() or "s"  
                gotoxy(65,3+line);print(colorVerde2+"✔"+colorReset)  
                
                diccionario = {"id": id, "descripcion": validar.eliminar_acentos(descripcion), "precio": float(precio), "stock": int(stock)}

                validarRepeticiones = validar.datos_repetidos_productos(diccionario)

                if validarRepeticiones:
                    validar.limpiar_campos(7, 65, 3+line)
                    gotoxy(50,3+line)
                    print(colorRojo2 + "Error, datos repetidos" + colorReset)
                    time.sleep(3)
                    validar.limpiar_campos(50, 65, 3+line)
                else: 
                    line += 1
                    lectura.append(diccionario)
                    break


        json_file.save(lectura)
        print()
        print(colorVerde1+"Agregando productos...")
        input("Presione una tecla para salir..."+colorReset)

    
    def update(self):
        json_file = JsonFile(path+'/archivos/products.json')
        lectura = json_file.read()
        validar = Valida()

        borrarPantalla()
        print('\033c', end='')
        gotoxy(2,2);print(colorVerde1+"*"*90+colorReset) 
        gotoxy(7,3); print("Ingrese el ID del producto (para modificar sus datos): ")
        id = int(validar.numeros_(colorRojo1+"valor invalido"+colorReset, 65,3))

        condicion = False
        
        for index, item in enumerate(lectura): 
            if id == item.get("id"): 
                condicion = True

                gotoxy(15,4);print(colorMagenta1+"ID") 
                gotoxy(30,4);print("Descripcion") 
                gotoxy(45,4);print("Precio") 
                gotoxy(60,4);print("Stock"+colorReset ) 

                gotoxy(15,5); print(item.get("id"))
                gotoxy(30,5); print(item.get("descripcion"))
                gotoxy(45,5); newPrecio = validar.precio(colorRojo2+"Error"+colorReset, 45,5)
                gotoxy(60,5); newStock = validar.stock(colorRojo2+"Valor incorr."+colorReset,60,5)

                # Actualiza el elemento en la lista con los nuevos valores
                lectura[index] = {"id": item.get("id"), "descripcion": item.get("descripcion"), "precio": float(newPrecio), "stock": int(newStock)}

                json_file.save(lectura)
                gotoxy(40,9);print(colorAzul1+"Cambio exitoso!!!")
                gotoxy(40,10); input("Presione una tecla para salir..."+colorReset)
                break
        
        if (condicion):
            return 
        else: 
            gotoxy(15,7);print(colorRojo2+"El cliente no se encuentra...")
            gotoxy(15,8);input("Presione una tecla para salir..."+colorReset)
    
    def delete(self):
        json_file = JsonFile(path+'/archivos/products.json')
        lectura = json_file.read()
        validar = Valida()

        borrarPantalla()
        print('\033c', end='')
        gotoxy(2,2);print(colorVerde1+"*"*90+colorReset) 
        gotoxy(7,3); print("Ingrese el ID del producto (para eliminarlo): ")
        id = validar.numeros_(colorRojo1+"valor invalido"+colorReset, 65,3)

        condicion = False

        for index, item in enumerate(lectura): 
            if id == item.get("id"): 
                condicion = True

                lectura.remove(lectura[index])
                json_file.save(lectura)
                gotoxy(40,9);print(colorAzul2+"Producto  eliminado con exito!!!")
                gotoxy(40,10);input("Presione una tecla para salir..."+colorReset)
                break
        
        if (condicion):
            return 
        else: 
            gotoxy(15,7);print(colorRojo2+"El producto no se encuentra...")
            gotoxy(15,8);input("Presione una tecla para salir..."+colorReset)
    
    def consult(self):
        json_file = JsonFile(path+'/archivos/products.json')
        lectura = json_file.read()
        validar = Valida()

        borrarPantalla()
        print('\033c', end='')
        gotoxy(2,2);print(colorVerde1+"*"*90+colorReset) 
        gotoxy(7,3); print("Ingrese el ID del producto que desea consultar: ")
        id = validar.numeros_(colorRojo1+"valor invalido"+colorReset, 55,3)

        condicion = False

        for index, item in enumerate(lectura): 
            if id == item.get("id"): 
                condicion = True

                table = Table()
                table.add_column("ID")
                table.add_column("Descripcion")
                table.add_column("Precio")
                table.add_column("Stock")

                table.add_row(f"{item.get("id")}", f"[green]{item.get("descripcion")}", f"[green]{item.get("precio")}", f"[green]{item.get("stock")}")
                
                console = Console()
                console.print(table)

                gotoxy(44,9);print(colorAzul1+"Producto consultado con exito!!!")
                gotoxy(44,9); input("Presione una tecla para salir..."+colorReset)
                break
        
        if (condicion):
            return 
        else: 
            gotoxy(15,7);print(colorRojo2+"El producto no se encuentra...")
            input("Presione una tecla para salir..."+colorReset)