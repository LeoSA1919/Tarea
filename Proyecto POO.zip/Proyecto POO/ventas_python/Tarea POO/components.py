from utilities import borrarPantalla, gotoxy
import time
from rich.table import Table 
from rich.console import Console
from clsJson import JsonFile
import os

path, _ = os.path.split(os.path.abspath(__file__))

class Menu:
    def __init__(self,titulo="",opciones=[],col=6,fil=1):
        self.titulo=titulo
        self.opciones=opciones
        self.col=col
        self.fil=fil
        
    def menu(self):
        gotoxy(self.col,self.fil);print(self.titulo)

        table = Table()
        table.add_column("Opciones")
        table.add_column("Descripcion")

        i = 0
        for opcion in range(0, len(self.opciones)): 
            i += 1
            table.add_row(f"{i}", f"[green]{self.opciones[opcion]}")

        console = Console()
        console.print(table)

        opc = input("Ingrese una opcion: ")  
        return opc

class Valida:
    def dinero(self,mensaje1, mensaje2,col,fil):
        while True: 
            gotoxy(col,fil)            
            valor = input()
            try:
                if int(valor) > 0 and int(valor) <= 100000:
                    break
                else: 
                    gotoxy(col,fil);print(mensaje1)
                    time.sleep(2)
                    gotoxy(col,fil);print(" "*20)
            except:
                gotoxy(col,fil);print(mensaje2)
                time.sleep(2)
                gotoxy(col,fil);print(" "*20)

        return valor
    
    def numeros_(self,mensajeError,col,fil):
        while True: 
            gotoxy(col,fil)            
            valor = input()
            try:
                if int(valor) > 0:
                    break
            except:
                gotoxy(col,fil);print(mensajeError)
                time.sleep(1)
                gotoxy(col,fil);print(" "*20)
        return valor
    
    def precio(self, mensaje1, mensaje2, col, fil):
        while True: 
            gotoxy(col,fil)            
            valor = input()
            try:
                if float(valor) > 0 and float(valor) <= 100:
                    break
                else: 
                    gotoxy(col,fil);print(mensaje1)
                    time.sleep(2)
                    gotoxy(col,fil);print(" "*20)
            except:
                gotoxy(col,fil);print(mensaje2)
                time.sleep(2)
                gotoxy(col,fil);print(" "*20)

        return valor
    
    def stock(self, mensaje1, mensaje2, col, fil):       # maximo de stock que debe tener un producto
        while True: 
            gotoxy(col,fil)            
            valor = input()
            try:
                if int(valor) >= 0 and int(valor) <= 10000:
                    break
                else: 
                    gotoxy(col,fil);print(mensaje1)
                    time.sleep(2)
                    gotoxy(col,fil);print(" "*20)
            except:
                gotoxy(col,fil);print(mensaje2)
                time.sleep(2)
                gotoxy(col,fil);print(" "*20)

        return valor
    
    def cedula_ingreso(self, cedula, diccionario):
        for cliente in diccionario:
            if cliente.get("dni") == cedula:
                return True
        return False


    def validacion_stock(self, mensaje1, mensaje2, col, fil, stock):     # verifica si el usuario quiera comprar un prodocto, sobrepasando el stock establecido
        while True:
            gotoxy(col,fil) 
            valor = input()
            try: 
                if int(valor) > 0:
                    if int(valor) <= stock: 
                        break
                    else: 
                        gotoxy(col,fil);print(mensaje1)
                        time.sleep(2)
                        gotoxy(col,fil);print(" "*20)
            except: 
                gotoxy(col,fil);print(mensaje2)
                time.sleep(2)
                gotoxy(col,fil);print(" "*20)

        return valor
    
    def letras_(self, mensaje, col, fil): 
        while True: 
            gotoxy(col,fil)            
            valor = input()

            if valor.isalpha():
                break
            else: 
                gotoxy(col,fil);print(mensaje)
                time.sleep(2)
                gotoxy(col,fil);print(" "*20)    
                
        return valor
                
    
    def cedula(self, mensaje, col, fil):
        while True: 
            gotoxy(col, fil)
            ced = input()
            cedSinEspaciosInFin = ced.strip()
            cedSplit = ced.split()

            if (len(cedSplit) > 1): 
                gotoxy(col,fil);print(mensaje)
                time.sleep(2)
                gotoxy(col,fil);print(" "*20)
            else: 
                suma = 0
                mul = 1
                index = len(cedSinEspaciosInFin)
                while index > 0:
                    index -= 1
                    num = int(cedSinEspaciosInFin[index]) * mul
                    suma += num - (num > 9) * 9
                    mul = 1 << index % 2

                if suma % 10 == 0 and suma > 0:
                    break
                else:
                    gotoxy(col,fil);print(mensaje)
                    time.sleep(2)
                    gotoxy(col,fil);print(" "*20)
                    

        return cedSinEspaciosInFin

    def eliminar_acentos(self, palabra):
        palabraEnMinuscula = palabra.lower() 
        diccionarioAcentos = {"á": "a", "é": "e", "í": "i", "ó": "o", "ú": "u", "à": "a", "è": "e", "ì": "i", "ò": "o", "ù": "u", "â": "a", "ê": "e", "î": "i", "ô": "o", "û": "u", "ä": "a", "ë": "e", "ï": "i", "ö": "o", "ü": "u", "ã": "a", "õ": "o", "ñ": "n"}

        for clave, valor in diccionarioAcentos.items(): 
            for letra in palabraEnMinuscula: 
                if clave == letra:
                    palabraEnMinuscula = palabraEnMinuscula.replace(letra, valor)

        return palabraEnMinuscula
    

    def datos_repetidos_clientes(self, diccionario): 
        json_file = JsonFile(path+'/archivos/clients.json')
        lectura = json_file.read()

        condicion = False 

        for elemento in lectura: 
            if elemento.get("dni") == diccionario.get("dni"): 
                condicion = True
                break 

        return condicion
    
    def datos_repetidos_productos(self, diccionario): 
        json_file = JsonFile(path+'/archivos/products.json')
        lectura = json_file.read()

        condicion = False 

        for elemento in lectura: 
            if elemento.get("descripcion") == diccionario.get("descripcion") or elemento.get("id") == diccionario.get("id"): 
                condicion = True
                break 

        return condicion

    def tipo_cliente(self, mensaje ,col, fil): 
        while True: 
            gotoxy(col,fil)  
            client = input()
            clientMinusculas = client.lower()

            if (clientMinusculas.isalpha()): 
                if (clientMinusculas == "vip" or clientMinusculas == "regular"): 
                    break
                else: 
                    gotoxy(col,fil);print(mensaje)
                    time.sleep(2)
                    gotoxy(col,fil);print(" "*20)
            else: 
                gotoxy(col,fil);print(mensaje)
                time.sleep(2)
                gotoxy(col,fil);print(" "*20)
            
        return clientMinusculas

    
        
    def limite_de_compras(self, mensaje, col, fil): 
        pass

    def limpiar_campos(self, desde_x, hasta_x, y):
        for x in range(desde_x, hasta_x + 1):
            gotoxy(x, y)
            print(" " * (hasta_x - desde_x + 1))