from utilities import borrarPantalla,gotoxy
from utilities import colorNegro1,colorNegro2,colorAzul1,colorAzul2,colorVerde1,colorVerde2,colorAmarillo1,colorAmarillo2,colorRojo1 ,colorRojo2,colorMagenta1,colorMagenta2 ,colorCyan1,colorCyan2, colorReset
from iCrud import ICrud
from company  import Company
import datetime
import time,os
from clsJson import JsonFile
from customer import RegularClient, VipClient
from sales import Sale
from functools import reduce
from product  import Product
from components import Valida

from rich.table import Table 
from rich.console import Console

path, _ = os.path.split(os.path.abspath(__file__))

class CrudSales(ICrud):
    def create(self):
        # cabecera de la venta
        validar = Valida()
        borrarPantalla()
        print('\033c', end='')
        gotoxy(2,1);print(colorVerde2+"*"*90)
        gotoxy(30,2);print("Registro de Venta")
        gotoxy(17,3);print(Company.get_business_name())
        gotoxy(5,4);print(f"Factura#:F0999999 {' '*3} Fecha:{datetime.datetime.now()}")
        gotoxy(66,4);print("Subtotal:")
        gotoxy(66,5);print("Decuento:")
        gotoxy(66,6);print("Iva     :")
        gotoxy(66,7);print("Total   :")
        gotoxy(15,6);print("DNI:"+colorReset)
        dni = validar.cedula(colorRojo1+"valor invalido"+colorReset,23,6)
        json_file = JsonFile(path+'/archivos/clients.json')
        lectura = json_file.read()

        condicion = False

        for elemento in lectura: 
            if elemento.get("dni") == dni: 
                usuario = elemento
                condicion = True
                cliente = elemento.get("tipo_cliente")

        if (condicion):
            if (cliente == "vip"): 
                cli = VipClient(usuario.get("nombre"), usuario.get("apellido"), usuario.get("dni"))
            else: 
                cli = RegularClient(usuario.get("nombre"), usuario.get("apellido"), usuario.get("dni"), card = True)

            gotoxy(35,6);print(cli.fullName())
            sale = Sale(cli)
            gotoxy(2,8);print(colorVerde1+"*"*90+colorReset) 
            gotoxy(5,9);print(colorMagenta2+"Linea") 
            gotoxy(12,9);print("Id_Articulo") 
            gotoxy(24,9);print("Descripcion") 
            gotoxy(38,9);print("Precio") 
            gotoxy(48,9);print("Cantidad") 
            gotoxy(58,9);print("Subtotal") 
            gotoxy(70,9);print("n->Terminar Venta)"+colorReset)

            follow ="s"
            line = 1

            while follow.lower() == "s":
                gotoxy(7,9+line);print(line)
                gotoxy(15,9+line);
                id = validar.numeros_(colorRojo2+"valor invalido"+colorReset,15,9+line)
                json_file = JsonFile(path+'/archivos/products.json')
                prods = json_file.find("id",id)
                if not prods:
                    gotoxy(24,9+line);print("Producto no existe")
                    time.sleep(1)
                    gotoxy(24,9+line);print(" "*20)
                else:    
                    prods = prods[0]
                    product = Product(prods["id"],prods["descripcion"],prods["precio"],prods["stock"])
                    gotoxy(24,9+line);print(product.descrip)
                    gotoxy(38,9+line);print(product.preci)
                    gotoxy(49,9+line);qyt= validar.validacion_stock(colorRojo2+"sobrepasó el stock"+colorReset, colorRojo1+"valor invalido"+colorReset, 49,9+line, product.stock)
                    gotoxy(59,9+line);print(product.preci*qyt)
                    sale.add_detail(product,qyt)
                    gotoxy(76,4);print(round(sale.subtotal,2))
                    gotoxy(76,5);print(round(sale.discount,2))
                    gotoxy(76,6);print(round(sale.iva,2))
                    gotoxy(76,7);print(round(sale.total,2))
                    gotoxy(74,9+line);follow=input() or "s"  
                    gotoxy(76,9+line);print(colorVerde2+"✔"+colorReset)  
                    line += 1

            gotoxy(15,9+line);print(colorAmarillo1+"Esta seguro de grabar la venta(s/n):"+colorReset)
            gotoxy(54,9+line);procesar = input().lower()

            if procesar == "s":
                gotoxy(15,12+line);print(colorVerde1+"😊 Venta Grabada satisfactoriamente 😊")
                # print(sale.getJson())  
                json_file = JsonFile(path+'/archivos/invoices.json')
                invoices = json_file.read()
                ult_invoices = invoices[-1]["factura"]+1
                data = sale.getJson()
                data["factura"]=ult_invoices
                invoices.append(data)
                json_file = JsonFile(path+'/archivos/invoices.json')
                json_file.save(invoices)
            else:
                gotoxy(20,10+line);print(colorVerde1+"💕 Venta Cancelada 💕")
            
            gotoxy(20,20); input("Presione una tecla para salir..."+colorReset)

        else: 
            gotoxy(35,6);
            print(colorAmarillo1+"⚠️ Cliente no existe, regrsando al inicio..."+colorReset)
            time.sleep(2)
            return

          
    def update(self):
        validar = Valida()
        json_file1 = JsonFile(path+'/archivos/invoices.json')
        lectura = json_file1.read()

        borrarPantalla()
        print('\033c', end='')
        gotoxy(2,1);print(colorVerde2+"*"*90+colorReset)
        gotoxy(30,2);print(colorAzul1+"Registro de Venta (modo: modificar)"+colorReset)
        gotoxy(4,4); print("¿Qué factura desea modificar?")
        factura = validar.numeros_(colorRojo1+"valor invalido"+colorReset,35,4)

        condicion = False

        for idx, elemento in enumerate(lectura): 
            if elemento.get("factura") == factura: 
                condicion = True
                gotoxy(12,7);print(colorMagenta1+"Factura") 
                gotoxy(24,7);print("Fecha") 
                gotoxy(38,7);print("Cliente"+colorReset) 

                gotoxy(12,8); print(factura)
                gotoxy(24,8); print(elemento.get("Fecha"))
                gotoxy(38,8); print(elemento.get("cliente"))

                i = 1
                gotoxy(12,10);print(colorMagenta1+"Producto")
                gotoxy(28,10);print("Precio")
                gotoxy(44,10);print("Cantidad"+colorReset)

                tableDetalles = Table()
                tableDetalles.add_column("Producto")
                tableDetalles.add_column("Precio")
                tableDetalles.add_column("Cantidad")

                for element in elemento.get("detalle"): 
                    json_file2 = JsonFile(path+'/archivos/products.json')
                    invoices = json_file2.read()

                    for products in invoices:
                        if element.get("producto") == products.get("descripcion"): 
                            stock_ = products.get("stock")
                            break

                    gotoxy(12, 10+i); print(element.get("producto"))
                    gotoxy(28, 10+i); precio = validar.precio(colorRojo1+"out of range"+colorReset,colorRojo1+"valor invalido"+colorReset, 28, 10+i)
                    gotoxy(44, 10+i); cantidad = validar.stock(colorRojo1+"out of range"+colorReset,colorRojo1+"valor invalido"+colorReset, 44, 10+i, stock_)

                    tableDetalles.add_row(f"{element.get('producto')}", f"{precio}", f"{cantidad}")
                    i += 1
                
                gotoxy(50,80); print("Procediendo a modificar...")

                tablePrincipal = Table()
                tablePrincipal.add_column("Factura: ")
                tablePrincipal.add_column("Fecha")
                tablePrincipal.add_column("Cliente")

                tablePrincipal.add_row(f"{factura}", f"{elemento.get("Fecha")}", f"{elemento.get('cliente')}")

                console1 = Console()
                console1.print(tablePrincipal)

                console2 = Console()
                console2.print(tableDetalles)

                gotoxy(50,85); print(f"Iva: {elemento.get('iva')}")
                gotoxy(50,15); print(f"Descuento: {elemento.get('descuento')}")

                subtotal = float(precio) * int(cantidad)
                gotoxy(50,90); print(F"Subtotal: {subtotal}")
                total = round(((subtotal * (1 - float(elemento.get('descuento')/100))) * (1 + float(elemento.get('iva')/100))),2)
                gotoxy(50,95); print(f"Total: {total}")

                # Modificar el registro en lectura
                lectura[idx] = {"factura": factura, "Fecha": elemento.get("Fecha"), "cliente": elemento.get("cliente"), "subtotal": subtotal, "descuento": elemento.get("descuento"), "iva": elemento.get("iva"), "total": total, "detalles": [{"producto": element.get("producto"), "precio": float(precio), "cantidad": int(cantidad)}]}

                json_file1.save(lectura)
                gotoxy(50,100); print(colorVerde1+"DATOS MODIFICADOS CORRECTAMENTE")
                gotoxy(50,110); input("Presione una tecla para salir..."+colorReset)
                break
            
        if condicion:
            return 
        else: 
            gotoxy(15,7);print(colorRojo2+"La factura no se encuentra...")
            gotoxy(15,8);input("Presione una tecla para salir..."+colorReset)
                
            if condicion:
                return 
            else: 
                gotoxy(15,7);print(colorRojo2+"La factura/venta no se encuentra...")
                gotoxy(15,8);input("Presione una tecla para salir..."+colorReset)

    def delete(self):
        json_file = JsonFile(path+'/archivos/invoices.json')
        lectura = json_file.read()
        validar = Valida()

        borrarPantalla()
        print('\033c', end='')
        gotoxy(2,2);print(colorVerde1+"*"*90+colorReset) 
        gotoxy(7,3); print("Ingrese la factura a eliminar: ")
        numFactura = validar.numeros_(colorRojo1+"Error"+colorReset, 38,3)

        condicion = False

        for index, item in enumerate(lectura): 
            if numFactura == item.get("factura"): 
                condicion = True

                lectura.remove(lectura[index])
                json_file.save(lectura)
                gotoxy(10,5);print(colorVerde1+"Venta eliminado con exito!!!")
                gotoxy(10,8); input("Presione una tecla para salir..."+colorReset)
                break
        
        if (condicion):
            return 
        else: 
            gotoxy(15,7);print(colorRojo2+"La factura no se encuentra...")
            gotoxy(15,8);input("Presione una tecla para salir..."+colorReset)
    
    def consult(self):    
        validar = Valida()
        json_file = JsonFile(path+'/archivos/invoices.json')
        lectura = json_file.read()

        print('\033c', end='')
        gotoxy(2,1);print(colorVerde1+"*"*90)
        gotoxy(2,2);print("Consulta de Venta"+colorReset)
        gotoxy(2,4);print("Ingrese un numero de factura: ")
        gotoxy(35,4); numFact = validar.numeros_(colorRojo1+"Err, solo numeros"+colorReset, 35,4)

        condicion = False

        for h in lectura: 
            if h.get("factura") == numFact: 
                condicion = True

                table1 = Table()
                table1.add_column("Factura")
                table1.add_column("Fecha")
                table1.add_column("cliente")
                table1.add_column("subtotal")
                table1.add_column("descuento")
                table1.add_column("iva")
                table1.add_column("total")
                table1.add_row(f"{h.get('factura')}", f"[green]{h.get('Fecha')}", f"[green]{h.get('cliente')}", f"[green]{h.get('subtotal')}", f"[green]{h.get('descuento')}", f"[green]{h.get('iva')}", f"[green]{h.get('total')}")

                console = Console()
                console.print(table1)

                table2 = Table()
                table2.add_column("Producto")
                table2.add_column("Precio")
                table2.add_column("Cantidad")

                for j in h.get("detalles"): 
                    table2.add_row(f"{j.get('producto')}", f"[green]{j.get('precio')}", f"[green]{j.get('cantidad')}")
                
                console = Console()
                gotoxy(21,10);print("Detalle")
                console.print(table2)

                gotoxy(35,20);print(colorVerde1+"Venta consultada con exito!!!")
                gotoxy(35,20);input("Presione una tecla para salir..."+colorReset)
                break

        if (condicion):
            return 
        else: 
            gotoxy(15,7);print(colorRojo2+"La factura/venta no se encuentra...")
            gotoxy(15,8);input("Presione una tecla para salir..."+colorReset)

        
        