from iCrud import ICrud
from utilities import borrarPantalla,gotoxy
from utilities import colorNegro1,colorNegro2,colorAzul1,colorAzul2,colorVerde1,colorVerde2,colorAmarillo1,colorAmarillo2,colorRojo1 ,colorRojo2,colorMagenta1,colorMagenta2 ,colorCyan1,colorCyan2, colorReset
from rich.table import Table 
from rich.console import Console
from rich.live import Live
import time,os
from components import Valida
from clsJson import JsonFile

path, _ = os.path.split(os.path.abspath(__file__))

class CrudClients(ICrud):
    def create(self):
        validar = Valida()
        borrarPantalla()
        print('\033c', end='')
        gotoxy(2,2);print(colorVerde1+"*"*110+colorReset) 
        gotoxy(7,3);print(colorMagenta1+"DNI"+colorReset) 
        gotoxy(20,3);print(colorMagenta1+"Nombre"+colorReset) 
        gotoxy(35,3);print(colorMagenta1+"apellido"+colorReset) 
        gotoxy(50,3);print(colorMagenta1+"Dinero dispon."+colorReset) 
        gotoxy(70,3);print(colorMagenta1+"Tipo cliente"+colorReset) 
        gotoxy(85,3);print(colorAzul2+"n-> finalizar agregacion"+colorReset)

        follow = "s"
        line = 1
        json_file = JsonFile(path+'/archivos/clients.json')
        lectura = json_file.read()
        arrayDatosNuevos = []   # para presentar en la tabla 

        while follow.lower() == "s":
            while True: 
                dni = validar.cedula(colorRojo2+"valor invalido"+colorReset, 7, 3+line)
                nombre = validar.letras_(colorRojo1+"valor invalido"+colorReset,20,3+line)
                apellido = validar.letras_(colorRojo1+"valor invalido"+colorReset, 35,3+line)
                dineroDisponible = validar.dinero(colorRojo2+"out of range"+colorReset, colorRojo2+"valor invalido"+colorReset,50,3+line)
                tipoCliente = validar.tipo_cliente(colorRojo2+"valor invalido"+colorReset,70,3+line)
                gotoxy(85,3+line); follow = input() or "s"  
                gotoxy(88,3+line); print(colorVerde2+"✔"+colorReset)  

                numUsuariosIngresados += 1
                
                diccionario_ = {"dni": dni, "nombre": validar.eliminar_acentos(nombre), "apellido": validar.eliminar_acentos(apellido), "dinero_disponible": int(dineroDisponible), "tipo_cliente": tipoCliente}
            
                validacionDatosRepetidos = validar.datos_repetidos_clientes(diccionario_)

                if validacionDatosRepetidos:
                    validar.limpiar_campos(7, 65, 3+line)
                    gotoxy(50,3+line)
                    print(colorRojo2 + "Error, cedula repetida" + colorReset)
                    time.sleep(3)
                    validar.limpiar_campos(50, 65, 3+line)
                else: 
                    line += 1
                    lectura.append(diccionario_)
                    arrayDatosNuevos.append(diccionario_)
                    break

        json_file.save(lectura)
        print()
        print()
        print(colorVerde1+"Agregando los siguientes clientes a `clients.json` ...")

        tabla = Table()
        tabla.add_column("DNI")
        tabla.add_column("Nombre")
        tabla.add_column("Apellido")
        tabla.add_column("Dinero Disponible")
        tabla.add_column("Tipo cliente")

        with Live(tabla, refresh_per_second = 2): 
            for row in arrayDatosNuevos: 
                time.sleep(0.8)
                tabla.add_row(f"[blue]{row.get("dni")}", f"[blue]{row.get("nombre")}", f"[blue]{row.get("apellido")}", f"[blue]{row.get("dinero_disponible")}", f"[green]{row.get("tipo_cliente")}")

        time.sleep(3)
        print()
        print()
        print("Cliente(s) agregado(s) con éxito!!")
        input("Presione una tecla para salir..."+colorReset)

    def update(self):
        json_file = JsonFile(path+'/archivos/clients.json')
        lectura = json_file.read()
        validar = Valida()

        borrarPantalla()
        print('\033c', end='')
        gotoxy(2,2);print(colorVerde1+"*"*90+colorReset) 
        gotoxy(7,3); print("Ingrese el DNI del cliente (para modificar sus datos): ")
        dni = validar.cedula(colorRojo2+"valor invalido"+colorReset, 62,3)

        condicion = False
        
        for index, item in enumerate(lectura): 
            if dni == item.get("dni"): 
                condicion = True

                gotoxy(15,6);print(colorMagenta1+"DNI"+colorReset) 
                gotoxy(30,6);print(colorMagenta1+"Nombre"+colorReset) 
                gotoxy(45,6);print(colorMagenta1+"Apellido"+colorReset) 
                gotoxy(60,6);print(colorMagenta1+"Dinero dispo."+colorReset)
                gotoxy(75, 6); print(colorMagenta1+"Tipo Cliente"+colorReset) 

                gotoxy(15,7); print(item.get("dni"))
                gotoxy(30,7); print(item.get("nombre"))
                gotoxy(45,7); print(item.get("apellido"))
                gotoxy(60,7); newDineroDisponible = validar.dinero(colorRojo2+"Out of range"+colorReset,colorRojo1+"valor invalido"+colorReset,60,7)
                gotoxy(75,7); newTipoCliente = validar.tipo_cliente(colorRojo2+"valor invalido"+colorReset,75,7)

                # Actualiza el elemento en la lista con los nuevos valores
                lectura[index] = {"dni": item.get("dni"), "nombre": item.get("nombre"), "apellido": item.get("apellido"), "dinero_disponible": int(newDineroDisponible), "tipo_cliente": newTipoCliente}

                json_file.save(lectura)
                gotoxy(40,9);print(colorAzul1+"Cambio exitoso!!!")
                gotoxy(40,10); input("Presione una tecla para salir..."+colorReset)
                break
        
        if (condicion):
            return 
        else: 
            gotoxy(15,7);print(colorRojo2+"El cliente no se encuentra...")
            gotoxy(15,8);input("Presione una tecla para salir..."+colorReset)

    def delete(self):
        json_file = JsonFile(path+'/archivos/clients.json')
        lectura = json_file.read()
        validar = Valida()

        borrarPantalla()
        print('\033c', end='')
        gotoxy(2,2);print(colorVerde1+"*"*90+colorReset) 
        gotoxy(7,3); print("Ingrese el DNI del cliente (para eliminarlo): ")
        dni = validar.cedula(colorRojo2+"valor invalido"+colorReset, 54,3)

        condicion = False

        for index, item in enumerate(lectura): 
            if dni == item.get("dni"): 
                condicion = True

                lectura.remove(lectura[index])
                json_file.save(lectura)
                gotoxy(40,9);print(colorAzul2+"Cliente eliminado con exito!!!")
                gotoxy(40,10);input("Presione una tecla para salir..."+colorReset)
                break
        
        if (condicion):
            return 
        else: 
            gotoxy(15,7);print(colorRojo2+"El cliente no se encuentra...")
            gotoxy(15,8);input("Presione una tecla para salir..."+colorReset)


    def consult(self):
        json_file = JsonFile(path+'/archivos/clients.json')
        lectura = json_file.read()
        validar = Valida()

        borrarPantalla()
        print('\033c', end='')
        gotoxy(2,2);print(colorVerde1+"*"*90+colorReset) 
        gotoxy(7,3); print("Ingrese el DNI del cliente que desea consultar: ")
        dni = validar.cedula(colorRojo1+"valor invalido"+colorReset, 55,3)

        condicion = False

        for index, item in enumerate(lectura): 
            if dni == item.get("dni"): 
                condicion = True

                table = Table()
                table.add_column("DNI")
                table.add_column("Nombre")
                table.add_column("Apellido")
                table.add_column("Dinero Disponible")
                table.add_column("Tipo cliente")

                table.add_row(f"{item.get("dni")}", f"[green]{item.get("nombre")}", f"[green]{item.get("apellido")}", f"[green]{item.get("dinero_disponible")}", f"[green]{item.get("tipo_cliente")}")
                
                console = Console()
                console.print(table)

                gotoxy(44,9);print(colorAzul1+"Cliente consultado con exito!!!")
                gotoxy(44,11); input("Presione una tecla para salir..."+colorReset)
                break
        
        if (condicion):
            return 
        else: 
            gotoxy(15,7);print(colorRojo2+"El cliente no se encuentra...")
            input("Presione una tecla para salir..."+colorReset)