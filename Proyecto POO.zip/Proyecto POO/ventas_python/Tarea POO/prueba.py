numeroString = "0968301348"

print(int(numeroString))