import os
import datetime
import time
from colorama import Fore, Back

# Variables globales: Colores en formato ANSI escape code

colorNegro1 = Fore.BLACK
colorNegro2 = Fore.LIGHTBLACK_EX
colorAzul1 = Fore.BLUE
colorAzul2 = Fore.LIGHTBLUE_EX
colorVerde1 = Fore.GREEN
colorVerde2 = Fore.LIGHTGREEN_EX
colorAmarillo1 = Fore.YELLOW
colorAmarillo2 = Fore.LIGHTYELLOW_EX
colorRojo1 = Fore.RED
colorRojo2= Fore.LIGHTRED_EX
colorMagenta1 = Fore.MAGENTA
colorMagenta2 = Fore.LIGHTMAGENTA_EX
colorCyan1 = Fore.CYAN
colorCyan2 = Fore.LIGHTCYAN_EX
colorReset = Fore.RESET

# funciones de usuario

def gotoxy(x,y):
    print("%c[%d;%df"%(0x1B,y,x),end="")

def borrarPantalla():
    os.system("cls") 

def mensaje(msg,f,c):
    pass

